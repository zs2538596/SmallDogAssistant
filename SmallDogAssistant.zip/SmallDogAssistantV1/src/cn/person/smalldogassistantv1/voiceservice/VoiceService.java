package cn.person.smalldogassistantv1.voiceservice;

import android.content.Context;
import cn.person.smalldogassistantv1.R;

import com.amap.api.navi.AMapNaviListener;
import com.amap.api.navi.model.AMapNaviLocation;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.SynthesizerListener;

public class VoiceService implements SynthesizerListener, AMapNaviListener {

	public static VoiceService VoiceManager;
	private Context mContext;
	boolean isfinish = true;
	// �ϳɶ���.
	private SpeechSynthesizer mSpeechSynthesizer;

	public VoiceService(Context context) {
		mContext = context;
	}

	public static VoiceService getInstance(Context context) {
		if (VoiceManager == null) {
			VoiceManager = new VoiceService(context);
		}
		return VoiceManager;
	}

	public void init() {
		SpeechUtility.createUtility(mContext, SpeechConstant.APPID
				+ "=���������뵽�Ŀƴ�Ѷ��������key");
		// ��ʼ���ϳɶ���.
		mSpeechSynthesizer = SpeechSynthesizer
				.createSynthesizer(mContext, null);
		initSpeechSynthesizer();
	}

	/**
	 * ʹ��SpeechSynthesizer�ϳ��������������ϳ�Dialog.
	 * 
	 * @param
	 */
	public void playText(String playText) {
		if (!isfinish) {
			return;
		}
		if (null == mSpeechSynthesizer) {
			// �����ϳɶ���.
			mSpeechSynthesizer = SpeechSynthesizer.createSynthesizer(mContext,
					null);
			initSpeechSynthesizer();
		}
		// ���������ϳ�.
		mSpeechSynthesizer.startSpeaking(playText, this);

	}

	public void stopSpeaking() {
		if (mSpeechSynthesizer != null)
			mSpeechSynthesizer.stopSpeaking();
	}

	private void initSpeechSynthesizer() {
		// ���÷�����
		mSpeechSynthesizer.setParameter(SpeechConstant.VOICE_NAME,
				mContext.getString(R.string.preference_default_tts_role));
		// ��������
		mSpeechSynthesizer.setParameter(SpeechConstant.SPEED,
				"" + mContext.getString(R.string.preference_key_tts_speed));
		// ��������
		mSpeechSynthesizer.setParameter(SpeechConstant.VOLUME,
				"" + mContext.getString(R.string.preference_key_tts_volume));
		// �������
		mSpeechSynthesizer.setParameter(SpeechConstant.PITCH,
				"" + mContext.getString(R.string.preference_key_tts_pitch));
		mSpeechSynthesizer.setParameter(SpeechConstant.TTS_AUDIO_PATH,
				"./sdcard/SmallDogVoice/voice.pcm");
		mSpeechSynthesizer.startSpeaking("��ʼ�����", mSynListener);
	}

	private SynthesizerListener mSynListener = new SynthesizerListener() {

		@Override
		public void onSpeakResumed() {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSpeakProgress(int arg0, int arg1, int arg2) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSpeakPaused() {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSpeakBegin() {
			// TODO Auto-generated method stub

		}

		@Override
		public void onCompleted(SpeechError arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onBufferProgress(int arg0, int arg1, int arg2, String arg3) {
			// TODO Auto-generated method stub

		}
	};

	public void destroy() {
		if (mSpeechSynthesizer != null) {
			mSpeechSynthesizer.stopSpeaking();
		}
	}

	@Override
	public void onArriveDestination() {
		// TODO Auto-generated method stub
		this.playText("����Ŀ�ĵ�");
	}

	@Override
	public void onArrivedWayPoint(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onCalculateRouteFailure(int arg0) {
		// TODO Auto-generated method stub
		this.playText("·������ʧ�ܣ�����������������");
	}

	@Override
	public void onCalculateRouteSuccess() {
		// TODO Auto-generated method stub
		String calculateResult = "·���������";

		this.playText(calculateResult);
	}

	@Override
	public void onEndEmulatorNavi() {
		// TODO Auto-generated method stub
		this.playText("��������");
	}

	@Override
	public void onGetNavigationText(int arg0, String arg1) {
		// TODO Auto-generated method stub
		this.playText(arg1);
	}

	@Override
	public void onGpsOpenStatus(boolean arg0) {

	}

	@Override
	public void onInitNaviFailure() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onInitNaviSuccess() {
		// this.playText("С������Ϊ������");
	}

	@Override
	public void onLocationChange(AMapNaviLocation location) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onReCalculateRouteForTrafficJam() {
		// TODO Auto-generated method stub
		this.playText("ǰ��·��ӵ�£�·�����¹滮");
	}

	@Override
	public void onReCalculateRouteForYaw() {
		// TODO Auto-generated method stub
		this.playText("����ƫ��");
	}

	@Override
	public void onStartNavi(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTrafficStatusUpdate() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onBufferProgress(int arg0, int arg1, int arg2, String arg3) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onCompleted(SpeechError arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSpeakProgress(int arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSpeakBegin() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSpeakPaused() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSpeakResumed() {
		// TODO Auto-generated method stub

	}

}