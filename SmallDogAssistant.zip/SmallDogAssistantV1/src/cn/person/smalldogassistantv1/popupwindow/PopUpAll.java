package cn.person.smalldogassistantv1.popupwindow;

import android.widget.PopupWindow;

public class PopUpAll extends PopupWindow {

}
