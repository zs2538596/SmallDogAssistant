package cn.person.smalldogassistantv1.navigation;

import com.amap.api.services.core.PoiItem;

public interface OnListItemClick {

	public void onListItemClick(RouteSearchPoiDialog dialog, PoiItem item);

}
