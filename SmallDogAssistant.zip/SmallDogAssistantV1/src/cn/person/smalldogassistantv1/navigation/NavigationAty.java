package cn.person.smalldogassistantv1.navigation;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import cn.person.smalldogassistantv1.R;
import cn.person.smalldogassistantv1.staticdata.StaticData;

import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.core.PoiItem;
import com.amap.api.services.poisearch.PoiItemDetail;
import com.amap.api.services.poisearch.PoiResult;
import com.amap.api.services.poisearch.PoiSearch;
import com.amap.api.services.poisearch.PoiSearch.OnPoiSearchListener;
import com.amap.api.services.route.BusPath;
import com.amap.api.services.route.BusRouteResult;
import com.amap.api.services.route.DrivePath;
import com.amap.api.services.route.DriveRouteResult;
import com.amap.api.services.route.RouteSearch;
import com.amap.api.services.route.RouteSearch.BusRouteQuery;
import com.amap.api.services.route.RouteSearch.DriveRouteQuery;
import com.amap.api.services.route.RouteSearch.OnRouteSearchListener;
import com.amap.api.services.route.RouteSearch.WalkRouteQuery;
import com.amap.api.services.route.WalkPath;
import com.amap.api.services.route.WalkRouteResult;

public class NavigationAty extends Activity implements OnClickListener,
		OnPoiSearchListener, OnRouteSearchListener, OnItemClickListener {
	private ImageButton btn_bus, btn_car, btn_walk, btn_back;
	private Button btn_clear_all, btn_route_search;
	private AutoCompleteTextView start_text, end_text;
	private LinearLayout mprogress;
	private ListView history;
	private HistroyAdapter adapter;
	private int mode = 2;
	private String startstr = null;
	private String endstr = null;

	// ***********************������ز���************************
	private RouteSearch routeSearch;
	private PoiSearch.Query startSearchQuery;
	private PoiSearch.Query endSearchQuery;
	private BusRouteResult busRouteResult;// ����ģʽ��ѯ���
	private DriveRouteResult driveRouteResult;// �ݳ�ģʽ��ѯ���
	private WalkRouteResult walkRouteResult;// ����ģʽ��ѯ��� @Override
	private int busMode = RouteSearch.BusDefault;// ����Ĭ��ģʽ
	private int drivingMode = RouteSearch.DrivingDefault;// �ݳ�Ĭ��ģʽ
	private int walkMode = RouteSearch.WalkDefault;// ����Ĭ��ģʽ
	private LatLonPoint startPoint;
	private LatLonPoint endPoint;
	private double latitude;
	private double longitude;
	private boolean full = false;
	private int length = 0;
	private int index = 0;
	private String temp_start = null;
	private String temp_end = null;

	// ********************************************************
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.route_search_layer);
		init();
	}

	private void getStartPoint() {
		Intent recive = this.getIntent();
		Bundle rebundle = recive.getExtras();
		try {
			latitude = rebundle.getDouble(StaticData.MLATITUDE);
		} catch (Exception e) {

		}
		try {
			longitude = rebundle.getDouble(StaticData.MLONGITUDE);
		} catch (Exception e) {

		}
		if (latitude != 0 && longitude != 0) {
			startPoint = new LatLonPoint(latitude, longitude);
		} else {
			startPoint = null;
		}

	}

	private void init() {
		mprogress = (LinearLayout) findViewById(R.id.myprogress);
		mprogress.setVisibility(View.GONE);

		btn_back = (ImageButton) findViewById(R.id.btn_back_route);
		btn_back.setOnClickListener(this);

		btn_bus = (ImageButton) findViewById(R.id.btn_bus);
		btn_bus.setOnClickListener(this);

		btn_car = (ImageButton) findViewById(R.id.btn_car);
		btn_car.setOnClickListener(this);

		btn_walk = (ImageButton) findViewById(R.id.btn_walk);
		btn_walk.setOnClickListener(this);

		start_text = (AutoCompleteTextView) findViewById(R.id.Edit_start_text);
		end_text = (AutoCompleteTextView) findViewById(R.id.Edit_end_text);

		btn_clear_all = (Button) findViewById(R.id.btn_clear_all);
		btn_clear_all.setOnClickListener(this);

		btn_route_search = (Button) findViewById(R.id.btn_route_search);
		btn_route_search.setOnClickListener(this);

		routeSearch = new RouteSearch(this);
		routeSearch.setRouteSearchListener(this);

		history = (ListView) findViewById(R.id.history_list);
		adapter = new HistroyAdapter(this);
		initListView();

		getStartPoint();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_bus:
			setBusMode();
			break;
		case R.id.btn_car:
			setCarMode();
			break;
		case R.id.btn_walk:
			setWalkMode();
			break;
		// ���ز���
		case R.id.btn_back_route:
			finish();
			break;
		case R.id.btn_clear_all:
			RemoveAllPreferences();
			break;
		case R.id.btn_route_search:
			RouteSearch();
			break;
		}

	}

	private void RouteSearch() {
		startstr = start_text.getText().toString().trim();
		endstr = end_text.getText().toString().trim();

		if (startPoint == null) {
			if (startstr == null || startstr.length() == 0) {
				ToastShow("δ��ȡ��ǰ���꣬���ֶ��������");
				return;
			}
		}

		if (endstr == null || endstr.length() == 0) {
			ToastShow("�������յ�");
			return;
		}
		if (startstr.equals(endstr)) {
			ToastShow("������յ����ܽ��������Բ���ǰ��");
			return;
		}

		startSearchResult();
	}

	private void ProgressShow() {
		mprogress.setVisibility(View.VISIBLE);
	}

	private void ProgressDismiss() {
		mprogress.setVisibility(View.GONE);
	}

	private void setBusMode() {
		mode = 0;
		btn_bus.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_bus_pressed));
		btn_car.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_car_unpressed));
		btn_walk.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_walk_unpressed));
	}

	private void setCarMode() {
		mode = 1;
		btn_bus.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_bus_unpressed));
		btn_car.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_car_pressed));
		btn_walk.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_walk_unpressed));
	}

	private void setWalkMode() {
		mode = 2;
		btn_bus.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_bus_unpressed));
		btn_car.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_car_unpressed));
		btn_walk.setImageDrawable(getResources().getDrawable(
				R.drawable.poi_walk_pressed));
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	private void ToastShow(String text) {
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	// *********************�б��е������***********************
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		ProgressShow();
		HistoryPathItem data = adapter.getItem(position);

		startstr = data.getStartname();
		start_text.setText(startstr);
		endstr = data.getEndname();
		end_text.setText(endstr);

		if (data.getStartname().equals("��ǰλ��")) {
			endSearchQuery = new PoiSearch.Query(endstr, "", "010"); // ��һ��������ʾ��ѯ�ؼ��֣��ڶ�������ʾpoi�������ͣ�������������ʾ�������Ż��߳�����
			endSearchQuery.setPageNum(0);// ���ò�ѯ�ڼ�ҳ����һҳ��0��ʼ
			endSearchQuery.setPageSize(20);// ����ÿҳ���ض���������

			PoiSearch poiSearch = new PoiSearch(NavigationAty.this,
					endSearchQuery);
			poiSearch.setOnPoiSearchListener(this);
			poiSearch.searchPOIAsyn(); // �첽poi��ѯ
		} else {
			startSearchResult();
		}

	}

	// ��������������ص�
	@Override
	public void onBusRouteSearched(BusRouteResult result, int rCode) {
		ProgressDismiss();
		if (rCode == 0) {
			if (result != null && result.getPaths() != null
					&& result.getPaths().size() > 0) {
				busRouteResult = result;
				StorageData(startstr, endstr);
				BusPath busPath = busRouteResult.getPaths().get(0);
				LatLonPoint tr_start = busRouteResult.getStartPos();
				LatLonPoint tr_end = busRouteResult.getTargetPos();

				double tr_latitude_start = tr_start.getLatitude();
				double tr_longitude_start = tr_start.getLongitude();

				double tr_latitude_end = tr_end.getLatitude();
				double tr_longitude_end = tr_end.getLongitude();
				// ������Ϣ
				Intent tr_Intent = new Intent();
				Bundle tr_Bundle = new Bundle();
				tr_Bundle.putParcelable(StaticData.BUS_PATH, busPath);
				tr_Bundle.putDouble(StaticData.START_LATITUDE,
						tr_latitude_start);
				tr_Bundle.putDouble(StaticData.START_LONGITUDE,
						tr_longitude_start);
				tr_Bundle.putDouble(StaticData.END_LATITUDE, tr_latitude_end);
				tr_Bundle.putDouble(StaticData.END_LONGITUDE, tr_longitude_end);

				tr_Intent.putExtras(tr_Bundle);

				setResult(StaticData.BUS_OK, tr_Intent);
				finish();

			} else {
				ToastShow("δ���������");
			}
		} else if (rCode == 27) {
			ToastShow("�������");
		} else if (rCode == 32) {
			ToastShow("key������");
		} else {
			ToastShow("��������");
		}
	}

	// �Լ���������ص�
	@Override
	public void onDriveRouteSearched(DriveRouteResult result, int rCode) {
		ProgressDismiss();
		if (rCode == 0) {
			if (result != null && result.getPaths() != null
					&& result.getPaths().size() > 0) {
				driveRouteResult = result;
				StorageData(startstr, endstr);
				DrivePath drivePath = driveRouteResult.getPaths().get(0);
				// ������Ϣ
				LatLonPoint tr_start = driveRouteResult.getStartPos();
				LatLonPoint tr_end = driveRouteResult.getTargetPos();

				double tr_latitude_start = tr_start.getLatitude();
				double tr_longitude_start = tr_start.getLongitude();

				double tr_latitude_end = tr_end.getLatitude();
				double tr_longitude_end = tr_end.getLongitude();
				// ������Ϣ
				Intent tr_Intent = new Intent();
				Bundle tr_Bundle = new Bundle();
				tr_Bundle.putParcelable(StaticData.CAR_PATH, drivePath);
				tr_Bundle.putDouble(StaticData.START_LATITUDE,
						tr_latitude_start);
				tr_Bundle.putDouble(StaticData.START_LONGITUDE,
						tr_longitude_start);
				tr_Bundle.putDouble(StaticData.END_LATITUDE, tr_latitude_end);
				tr_Bundle.putDouble(StaticData.END_LONGITUDE, tr_longitude_end);

				tr_Intent.putExtras(tr_Bundle);

				setResult(StaticData.CAR_OK, tr_Intent);
				finish();
			} else {
				ToastShow("δ���������");
			}
		} else if (rCode == 27) {
			ToastShow("�������");
		} else if (rCode == 32) {
			ToastShow("key������");
		} else {
			ToastShow("��������");
		}
	}

	// ������������ص�
	@Override
	public void onWalkRouteSearched(WalkRouteResult result, int rCode) {
		ProgressDismiss();
		if (rCode == 0) {
			if (result != null && result.getPaths() != null
					&& result.getPaths().size() > 0) {
				walkRouteResult = result;
				StorageData(startstr, endstr);
				WalkPath walkPath = walkRouteResult.getPaths().get(0);
				// ������Ϣ
				LatLonPoint tr_start = walkRouteResult.getStartPos();
				LatLonPoint tr_end = walkRouteResult.getTargetPos();

				double tr_latitude_start = tr_start.getLatitude();
				double tr_longitude_start = tr_start.getLongitude();

				double tr_latitude_end = tr_end.getLatitude();
				double tr_longitude_end = tr_end.getLongitude();
				// ������Ϣ
				Intent tr_Intent = new Intent();
				Bundle tr_Bundle = new Bundle();
				tr_Bundle.putParcelable(StaticData.WALK_PATH, walkPath);
				tr_Bundle.putDouble(StaticData.START_LATITUDE,
						tr_latitude_start);
				tr_Bundle.putDouble(StaticData.START_LONGITUDE,
						tr_longitude_start);
				tr_Bundle.putDouble(StaticData.END_LATITUDE, tr_latitude_end);
				tr_Bundle.putDouble(StaticData.END_LONGITUDE, tr_longitude_end);

				tr_Intent.putExtras(tr_Bundle);

				setResult(StaticData.WALK_OK, tr_Intent);
				finish();
			} else {
				ToastShow("δ���������");
			}
		} else if (rCode == 27) {
			ToastShow("�������");
		} else if (rCode == 32) {
			ToastShow("key������");
		} else {
			ToastShow("��������");
		}
	}

	@Override
	public void onPoiItemDetailSearched(PoiItemDetail arg0, int arg1) {

	}

	// poi��������ص�
	@Override
	public void onPoiSearched(PoiResult result, int rCode) {
		ProgressDismiss();
		if (rCode == 0) {
			if (result != null && result.getQuery() != null
					&& result.getPois() != null && result.getPois().size() > 0) {
				if (result.getQuery().queryEquals(startSearchQuery)) {
					// ������صĽ��Ϊ��ʼ�������Ľ��
					List<PoiItem> poiItems = result.getPois();// ȡ��poiitem����
					RouteSearchPoiDialog dialog = new RouteSearchPoiDialog(
							NavigationAty.this, poiItems);// ͨ�����캯��������dialog��ListView�����������������ݽ������
					dialog.setTitle("��Ҫ�ҵ������:");
					dialog.show();
					dialog.setOnListClickListener(new OnListItemClick() {

						@Override
						public void onListItemClick(
								RouteSearchPoiDialog dialog,
								PoiItem startpoiItem) {
							startPoint = startpoiItem.getLatLonPoint();
							startstr = startpoiItem.getTitle();
							start_text.setText(startstr);
							endSearchResult();// ��ʼ���յ�
						}
					});
				} else if (result.getQuery().queryEquals(endSearchQuery)) {
					// ������صĽ��Ϊ�����������Ľ��
					List<PoiItem> poiItems = result.getPois();// ȡ��poiitem����
					RouteSearchPoiDialog dialog = new RouteSearchPoiDialog(
							NavigationAty.this, poiItems);
					dialog.setTitle("��Ҫ�ҵ��յ���:");
					dialog.show();
					dialog.setOnListClickListener(new OnListItemClick() {
						public void onListItemClick(
								RouteSearchPoiDialog dialog, PoiItem endpoiItem) {
							endPoint = endpoiItem.getLatLonPoint();
							endstr = endpoiItem.getTitle();
							end_text.setText(endstr);
							// ����·���滮����
							searchRouteResult(startPoint, endPoint);
						}
					});
				}
			} else {
				ToastShow("δ���������");
			}
		} else if (rCode == 27) {
			ToastShow("�������");
		} else if (rCode == 32) {
			ToastShow("key������");
		} else {
			System.out.println(rCode);
			ToastShow("��������");
		}

	}

	private void startSearchResult() {
		startstr = start_text.getText().toString().trim();
		if (startstr != null && startstr.length() != 0) {
			ProgressShow();
			startSearchQuery = new PoiSearch.Query(startstr, "", "010"); // ��һ��������ʾ��ѯ�ؼ��֣��ڶ�������ʾpoi�������ͣ�������������ʾ�������Ż��߳�����
			startSearchQuery.setPageNum(0);// ���ò�ѯ�ڼ�ҳ����һҳ��0��ʼ
			startSearchQuery.setPageSize(20);// ����ÿҳ���ض���������
			PoiSearch poiSearch = new PoiSearch(NavigationAty.this,
					startSearchQuery);
			poiSearch.setOnPoiSearchListener(this);
			poiSearch.searchPOIAsyn();// �첽poi��ѯ
		} else if (startPoint != null) {
			endSearchResult();
		}
	}

	public void endSearchResult() {
		endstr = end_text.getText().toString().trim();
		if (endPoint != null && endstr.equals("��ͼ�ϵ��յ�")) {
			searchRouteResult(startPoint, endPoint);
		} else {
			ProgressShow();
			endSearchQuery = new PoiSearch.Query(endstr, "", "010"); // ��һ��������ʾ��ѯ�ؼ��֣��ڶ�������ʾpoi�������ͣ�������������ʾ�������Ż��߳�����
			endSearchQuery.setPageNum(0);// ���ò�ѯ�ڼ�ҳ����һҳ��0��ʼ
			endSearchQuery.setPageSize(20);// ����ÿҳ���ض���������

			PoiSearch poiSearch = new PoiSearch(NavigationAty.this,
					endSearchQuery);
			poiSearch.setOnPoiSearchListener(this);
			poiSearch.searchPOIAsyn(); // �첽poi��ѯ
		}
	}

	public void searchRouteResult(LatLonPoint start, LatLonPoint end) {
		ProgressShow();
		final RouteSearch.FromAndTo fromAndTo = new RouteSearch.FromAndTo(
				start, end);
		if (mode == 0) {// ����·���滮
			BusRouteQuery query = new BusRouteQuery(fromAndTo, busMode, "����", 0);// ��һ��������ʾ·���滮�������յ㣬�ڶ���������ʾ������ѯģʽ��������������ʾ������ѯ�������ţ����ĸ�������ʾ�Ƿ����ҹ�೵��0��ʾ������
			routeSearch.calculateBusRouteAsyn(query);// �첽·���滮����ģʽ��ѯ
		} else if (mode == 1) {// �ݳ�·���滮
			DriveRouteQuery query = new DriveRouteQuery(fromAndTo, drivingMode,
					null, null, "");// ��һ��������ʾ·���滮�������յ㣬�ڶ���������ʾ�ݳ�ģʽ��������������ʾ;���㣬���ĸ�������ʾ�������򣬵����������ʾ���õ�·
			routeSearch.calculateDriveRouteAsyn(query);// �첽·���滮�ݳ�ģʽ��ѯ
		} else if (mode == 2) {// ����·���滮
			WalkRouteQuery query = new WalkRouteQuery(fromAndTo, walkMode);
			routeSearch.calculateWalkRouteAsyn(query);// �첽·���滮����ģʽ��ѯ
		}
	}

	// **************************�����ʷ��¼�洢����************************
	public void StorageData(String startname, String endname) {
		SharedPreferences pref = getSharedPreferences(
				StaticData.SMALL_DOG_PREFERENCE, Context.MODE_PRIVATE);
		Editor e = pref.edit();

		int temp_length = 0;
		if (pref.getBoolean(StaticData.FULL, false) == true) {
			temp_length = StaticData.MAX_STORAGE_LENGTH;
		} else {
			temp_length = pref.getInt(StaticData.INDEX, 0);
		}

		boolean isSame = ExcludeSameItems(startname, endname, temp_length, pref);

		if (isSame == false) {
			index = pref.getInt(StaticData.INDEX, 0);
			if (startname == null || startname.length() == 0) {
				e.putString(StaticData.START_NAME + index, "��ǰλ��");
			} else {
				e.putString(StaticData.START_NAME + index, startname);
			}
			e.putString(StaticData.END_NAME + index, endname);
			// SharedPrefrences������ܴ������ΪMAX_STORAGE_LENGTH����Ϊ30������֮���ͷ����
			index++;
			if (index == StaticData.MAX_STORAGE_LENGTH) {
				full = true;
				e.putBoolean(StaticData.FULL, full);
			}
			index = index % (StaticData.MAX_STORAGE_LENGTH);
			e.putInt(StaticData.INDEX, index);
			e.commit();
		}
	}

	public boolean ExcludeSameItems(String startname, String endname,
			int length, SharedPreferences pref) {
		String temp = null;
		if (startname == null || startname.length() == 0) {
			temp = "��ǰλ��";
		} else {
			temp = startname;
		}
		for (int i = 0; i < length; i++) {
			temp_start = pref.getString(StaticData.START_NAME + i, null);
			temp_end = pref.getString(StaticData.END_NAME + i, null);
			if (temp.equals(temp_start) && endname.equals(temp_end)) {
				return true;
			}
		}
		return false;
	}

	private void RemoveAllPreferences() {
		SharedPreferences pref = getSharedPreferences(
				StaticData.SMALL_DOG_PREFERENCE, Context.MODE_PRIVATE);
		Editor e = pref.edit();
		int index = pref.getInt(StaticData.INDEX, 0);
		boolean full = pref.getBoolean(StaticData.FULL, false);
		int length = 0;
		if (full == true) {
			length = StaticData.MAX_STORAGE_LENGTH;
		} else {
			length = index;
		}
		// Ѱ������
		for (int i = 0; i < length; i++) {
			if (adapter.isEmpty() == false)
				adapter.removeItem(0);
			if (pref.contains(StaticData.START_NAME + i)) {
				e.remove(StaticData.START_NAME + i);
				e.remove(StaticData.END_NAME + i);
			}
		}

		index = 0;
		full = false;
		e.putBoolean(StaticData.FULL, full);
		e.putInt(StaticData.INDEX, index);
		e.commit();
	}

	private void initListView() {
		SharedPreferences pref = getSharedPreferences(
				StaticData.SMALL_DOG_PREFERENCE, Context.MODE_PRIVATE);
		if (pref.getInt(StaticData.INDEX, 0) != 0
				|| pref.getBoolean(StaticData.FULL, false) == true) {

			if (pref.getBoolean(StaticData.FULL, false) == true) {
				length = StaticData.MAX_STORAGE_LENGTH;
			} else {
				length = pref.getInt(StaticData.INDEX, 0);
			}
			for (int i = 0; i < length; i++) {
				HistoryPathItem data = new HistoryPathItem(pref.getString(
						StaticData.START_NAME + i, null), pref.getString(
						StaticData.END_NAME + i, null));
				adapter.addData(data);
			}
			history.setAdapter(adapter);
		}
		history.setOnItemClickListener(this);
	}
}
